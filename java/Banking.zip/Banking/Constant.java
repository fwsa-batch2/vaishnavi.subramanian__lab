package Banking;
public class Constant {
    public static String bankName = "ICICI";
}

